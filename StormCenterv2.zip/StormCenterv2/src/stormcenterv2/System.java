/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stormcenterv2;

import java.util.ArrayList;

/**
 *
 * @author Cristiano
 */
public class System 
{
    private ArrayList<Storm> storms = new ArrayList<>();
    
    public ArrayList<Storm> getStormList()
    {
        return storms;
    }
    public boolean sizeCheck()
    {
        if(storms.size()>= 20)
        {
            return false;
        }
        return true;
    }
    public int typeCheck(String typeIn)
    {
        if(typeIn.equals("Hurricane")){             //turn if's into Switch cases
            return 1;
        }
        else if(typeIn.equals("Tornado")){
            return 2;
        }
        else if (typeIn.equals("Blizzard")){
            return 3;
        }
        else{
            return 0;
        }
    }    
    public void addStorm(String nameIn, int windIn, int tempIn,String typeIn)
    {
        Hurricane hurricane = new Hurricane(nameIn, windIn, tempIn);
        Tornado tornado = new Tornado(nameIn, windIn, tempIn);
        Blizzard blizzard = new Blizzard(nameIn, windIn, tempIn);
        
        switch (typeCheck(typeIn)) {
            case 1:            
                storms.add(hurricane);
                break;
            case 2:
                storms.add(tornado);
                break;
            case 3:
                storms.add(blizzard);
                break;
            default:
                break;
        }
    }    
    public String addStormCheck (String nameIn, int windIn, int tempIn, String typeIn)
    {
        if(sizeCheck())
        {
            if(typeCheck(typeIn)!=0)
            {
                addStorm(nameIn, windIn, tempIn, typeIn);
                return "Storm Added";
            }
            return "random text";       //this might not be needed
        }
        return "<html>Storm System is operating at full capacity<BR>"
                            + "Unable to add any more storms to the system</html>";
    }        
}
