package stormcenterv2;
/**
 *
 * @author Cristiano
 */
public class StormCenterv2 {
    
    public static void main(String[] args) 
    {        
        Screen gui = new Screen();
        gui.pack();
        gui.setVisible(true);    
    }        
}